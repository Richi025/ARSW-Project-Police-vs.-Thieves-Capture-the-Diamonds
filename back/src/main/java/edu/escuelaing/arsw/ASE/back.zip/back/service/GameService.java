package edu.escuelaing.arsw.ASE.back.service;

import edu.escuelaing.arsw.ASE.back.model.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Logger;

@Service
public class GameService {

    private static final Logger logger = Logger.getLogger(GameService.class.getName());

    private ConcurrentMap<String, GameMatrix> gameMatrices = new ConcurrentHashMap<>();

    public void initializeGame(String gameId, List<Player> players) {
        GameMatrix gameMatrix = new GameMatrix(600, 800);

        gameMatrix.placePlayers(players);

        gameMatrices.put(gameId, gameMatrix);
    }

    public void updatePosition(String gameId, int row, int col, int value) {
        GameMatrix gameMatrix = gameMatrices.get(gameId);
        if (gameMatrix != null) {
            gameMatrix.setPosition(row, col, value);
        }
    }

    public int[][] getGameState(String gameId, List<Player> players) {
        GameMatrix gameMatrix = gameMatrices.get(gameId);
        if (gameMatrix == null) {
            System.out.println("Game not found, initializing default game.");
            initializeGame(gameId, players); // Ensure game is initialized if not found
            gameMatrix = gameMatrices.get(gameId);
        }
        if (gameMatrix != null) {
            gameMatrix.placePlayers(players);
            System.out.println("Returning game state for game ID: " + gameId);
            return gameMatrix.getMatrix();
        }
        return new int[600][800]; // Return an empty matrix if something goes wrong
    }

    private List<Player> getPlayersFromRepository(String gameId) {
        // Implementar lógica para obtener los jugadores del repositorio
        return List.of(); // Ejemplo de implementación
    }

    // Método para printear gameMatrices
    public void printGameMatrices() {
        gameMatrices.forEach((gameId, gameMatrix) -> {
            System.out.println("Game ID: " + gameId);
            int[][] matrix = gameMatrix.getMatrix();
            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix[i].length; j++) {
                    System.out.print(matrix[i][j] + " ");
                }
                System.out.println();
            }
        });
    }
}
