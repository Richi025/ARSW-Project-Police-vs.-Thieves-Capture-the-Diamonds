package edu.escuelaing.arsw.ASE.back;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.escuelaing.arsw.ASE.back.service.GameService;


@SpringBootApplication
public class GameApplication implements CommandLineRunner{

	@Autowired
    private GameService service;
    

	public static void main(String[] args) {
		SpringApplication.run(GameApplication.class, args);
	}



    @Override
    public void run(String... args) throws Exception {
        
        service.printGameMatrices();
    }
}