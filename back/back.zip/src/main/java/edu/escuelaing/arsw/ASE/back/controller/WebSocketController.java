package edu.escuelaing.arsw.ASE.back.controller;

import edu.escuelaing.arsw.ASE.back.model.Player;
import edu.escuelaing.arsw.ASE.back.model.GameMatrix;
import edu.escuelaing.arsw.ASE.back.service.GameService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

@Component
public class WebSocketController extends TextWebSocketHandler {

    private static CopyOnWriteArrayList<WebSocketSession> sessions = new CopyOnWriteArrayList<>();
    private static ConcurrentHashMap<String, GameMatrix> gameStates = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String, Boolean> playerReadyStatus = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String, String> playerNames = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String, Player> players = new ConcurrentHashMap<>();
    private static int totalPlayers = 2;  // Número total de jugadores necesarios para comenzar el juego
    private static Gson gson = new Gson();

    @Autowired
    private GameService gameService;

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessions.add(session);
        gameStates.put(session.getId(), new GameMatrix());
        playerReadyStatus.put(session.getId(), false); // Asegúrate de que el jugador no esté listo inicialmente
        playerNames.put(session.getId(), "Unknown"); // Nombre predeterminado

        updatePlayersStatus();
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        String payload = message.getPayload();
        Map<String, Object> data = gson.fromJson(payload, Map.class);

        if ("JOIN".equals(data.get("type"))) {
            handleJoinMessage(data, session);
        } else if ("PLAYER_READY".equals(data.get("type"))) {
            playerReadyStatus.put(session.getId(), true);
            updatePlayersStatus();

            if (allPlayersReady()) {
                startGame();
            }
        } else if ("PLAYER_MOVE".equals(data.get("type"))) {
            handlePlayerMoveMessage(data, session);
        } else {
            GameMatrix gameState = gameStates.get(session.getId());
            // Actualizar el estado del juego basado en el mensaje
            // ...

            // Transmitir el estado actualizado a todos los clientes
            sendGameStateToAllSessions(gameState);
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        sessions.remove(session);
        gameStates.remove(session.getId());
        playerReadyStatus.remove(session.getId());
        playerNames.remove(session.getId());
        players.remove(session.getId());

        updatePlayersStatus();
    }

    private void updatePlayersStatus() throws Exception {
        List<Map<String, Object>> playersStatus = new ArrayList<>();
        for (WebSocketSession session : sessions) {
            Player player = players.get(session.getId());
            if (player != null) {
                Map<String, Object> playerStatus = new HashMap<>();
                playerStatus.put("id", player.getId());
                playerStatus.put("name", player.getName());
                playerStatus.put("top", player.getTop());
                playerStatus.put("left", player.getLeft());
                playerStatus.put("isThief", player.isThief());
                playerStatus.put("isReady", playerReadyStatus.get(session.getId()).toString());
                playersStatus.add(playerStatus);
            }
        }

        Map<String, Object> message = new HashMap<>();
        message.put("type", "UPDATE_PLAYERS");
        message.put("players", playersStatus);

        String jsonMessage = gson.toJson(message);

        sendToAllSessions(jsonMessage);
    }

    private boolean allPlayersReady() {
        return playerReadyStatus.values().stream().allMatch(Boolean::booleanValue);
    }

    private void startGame() throws Exception {
        GameMatrix initialMatrix = gameService.initializePlayers(new ArrayList<>(players.values()));
        String initialMatrixJson = convertMatrixToJson(initialMatrix);

        Map<String, Object> message = new HashMap<>();
        message.put("type", "START_GAME");
        message.put("matrix", initialMatrix.getMatrix());
        message.put("players", players.values());

        String jsonMessage = gson.toJson(message);

        sendToAllSessions(jsonMessage);
    }

    private void handleJoinMessage(Map<String, Object> data, WebSocketSession session) {
        int playerId = ((Double) data.get("id")).intValue();
        String playerName = (String) data.get("name");
        int top = ((Double) data.get("top")).intValue();
        int left = ((Double) data.get("left")).intValue();
        boolean isThief = (Boolean) data.get("isThief");
        Player player = new Player(playerId, playerName, top, left, isThief);
        players.put(session.getId(), player);
        playerNames.put(session.getId(), playerName); // Actualizar nombre del jugador

        try {
            sendPlayerListUpdate();
        } catch (Exception e) {
            System.out.println("error handleJoinMessage");
            e.printStackTrace();
        }
    }

    private Player parsePlayerMove(Map<String, Object> data) {
        int playerId = ((Double) data.get("id")).intValue();
        String playerName = (String) data.get("name");
        int top = ((Double) data.get("top")).intValue();
        int left = ((Double) data.get("left")).intValue();
        boolean isThief = (Boolean) data.get("isThief");
        return new Player(playerId, playerName, top, left, isThief);
    }

    private void handlePlayerMoveMessage(Map<String, Object> data, WebSocketSession session) throws Exception {
        Player playerMove = parsePlayerMove(data);
        GameMatrix updatedMatrix = gameService.updatePlayerPosition(playerMove);
        String updatedMatrixJson = convertMatrixToJson(updatedMatrix);
        sendToAllSessions(updatedMatrixJson);
    }

    private String convertMatrixToJson(GameMatrix matrix) {
        return gson.toJson(matrix);
    }

    private void sendToAllSessions(String message) throws Exception {
        for (WebSocketSession session : sessions) {
            if (session.isOpen()) {
                try {
                    session.sendMessage(new TextMessage(message));
                } catch (Exception e) {
                    e.printStackTrace(); // Manejo básico de excepciones, mejoraría esto en producción
                }
            }
        }
    }

    private void sendPlayerListUpdate() throws Exception {
        List<Map<String, Object>> playersStatus = new ArrayList<>();
        for (WebSocketSession session : sessions) {
            Player player = players.get(session.getId());
            if (player != null) {
                Map<String, Object> playerStatus = new HashMap<>();
                playerStatus.put("id", player.getId());
                playerStatus.put("name", player.getName());
                playerStatus.put("top", player.getTop());
                playerStatus.put("left", player.getLeft());
                playerStatus.put("isThief", player.isThief());
                playerStatus.put("isReady", playerReadyStatus.get(session.getId()).toString());
                playersStatus.add(playerStatus);
            }
        }

        Map<String, Object> message = new HashMap<>();
        message.put("type", "UPDATE_PLAYERS");
        message.put("players", playersStatus);

        String jsonMessage = gson.toJson(message);

        sendToAllSessions(jsonMessage);
    }

    private void sendGameStateToAllSessions(GameMatrix gameState) throws Exception {
        String gameStateJson = gson.toJson(gameState);
        sendToAllSessions(gameStateJson);
    }
}
