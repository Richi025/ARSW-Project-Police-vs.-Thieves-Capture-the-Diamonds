// src/Lobby.js
import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import styled from 'styled-components';

const LobbyContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #282c34;
`;

const PlayerList = styled.div`
  margin-bottom: 20px;
`;

const PlayerItem = styled.div`
  margin: 5px 0;
  color: white;
`;

const ReadyButton = styled.button`
  padding: 10px 20px;
  font-size: 1.2em;
  background-color: #4CAF50;
  color: white;
  border: none;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #45a049;
  }

  &:disabled {
    background-color: #ccc;
    cursor: not-allowed;
  }
`;

const Lobby = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [players, setPlayers] = useState([]);
  const [isReady, setIsReady] = useState(false);
  const player = location.state.player;
  const socketRef = useRef(null);

  useEffect(() => {
    const socket = new WebSocket('ws://localhost:8080/lobby');
    socketRef.current = socket;

    socket.onopen = () => {
      console.log('WebSocket connection established');
      socket.send(JSON.stringify({ type: 'JOIN', ...player }));
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'UPDATE_PLAYERS') {
        setPlayers(data.players);
      } else if (data.type === 'START_GAME') {
        navigate('/game', { state: { player, socket: socketRef.current } });
      }
    };

    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [navigate, player]);

  const handleReady = () => {
    setIsReady(true);
    if (socketRef.current) {
      socketRef.current.send(JSON.stringify({ type: 'PLAYER_READY', ...player }));
    }
  };

  return (
    <LobbyContainer>
      <h1>Lobby</h1>
      <PlayerList>
        {players.map((p, index) => (
          <PlayerItem key={index}>
            {p.name} ({p.isThief ? 'Thief' : 'Police'}) {p.ready ? '✔️' : '❌'}
          </PlayerItem>
        ))}
      </PlayerList>
      <ReadyButton onClick={handleReady} disabled={isReady}>Ready</ReadyButton>
    </LobbyContainer>
  );
};

export default Lobby;
