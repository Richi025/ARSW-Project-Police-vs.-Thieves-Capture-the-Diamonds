// src/config/config.js
const config = {
  BASE_URL: 'http://localhost:8080',
  socketUrl: 'http://localhost:8080/game-websocket'
};

export default config;

  
