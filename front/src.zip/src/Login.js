// src/Login.js
import React, { useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import facadeImage from './images/Fondo.jpg';

const LoginContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #282c34;
`;

const FacadeImage = styled.img`
  max-width: 100%;
  max-height: 70vh;
  margin-bottom: 20px;
  border: 2px solid black;
`;

const StartButton = styled.button`
  padding: 10px 20px;
  font-size: 1.2em;
  background-color: #4CAF50;
  color: white;
  border: none;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #45a049;
  }
`;

const Input = styled.input`
  padding: 10px;
  margin: 10px 0;
  font-size: 1em;
`;

const positionsPolice = [
  { top: 150, left: 250 },
  { top: 160, left: 260 },
  { top: 170, left: 270 },
  { top: 180, left: 280 },
];

const positionsThief = [
  { top: 5, left: 5 },
  { top: 15, left: 15 },
  { top: 25, left: 25 },
  { top: 35, left: 35 },
];

const Login = () => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('thief');
  const navigate = useNavigate();

  const startGame = () => {
    if (name) {
      const initialPosition = role === 'thief' ? positionsThief[0] : positionsPolice[0];
      const playerData = { 
        id: Date.now(), // Generate a unique ID for the player
        name, 
        top: initialPosition.top, 
        left: initialPosition.left, 
        isThief: role === 'thief'
      };
      navigate('/lobby', { state: { player: playerData } });
    } else {
      alert('Please enter a name');
    }
  };

  return (
    <LoginContainer>
      <FacadeImage src={facadeImage} alt="Facade" />
      <Input type="text" placeholder="Enter your name" value={name} onChange={(e) => setName(e.target.value)} />
      <div>
        <label>
          <input type="radio" value="thief" checked={role === 'thief'} onChange={() => setRole('thief')} />
          Thief
        </label>
        <label>
          <input type="radio" value="police" checked={role === 'police'} onChange={() => setRole('police')} />
          Police
        </label>
      </div>
      <StartButton onClick={startGame}>Jugar</StartButton>
    </LoginContainer>
  );
};

export default Login;
