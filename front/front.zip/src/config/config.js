// src/config.js
const config = {
    BASE_URL: 'http://localhost:8080', // Cambia esto si tu backend está corriendo en un puerto diferente
  };
  
  export default config;
  
