
const diamonds = [
    { id: 1, top: 165, left: 215 },
    { id: 2, top: 165, left: 365 },
    { id: 3, top: 115, left: 290 },
    { id: 4, top: 315, left: 415 },
    { id: 5, top: 15, left: 650 },
    { id: 6, top: 20, left: 460 },
    { id: 7, top: 70, left: 515 },
    { id: 8, top: 315, left: 515 },
    { id: 9, top: 375, left: 515 },
    { id: 11, top: 465, left: 515 },
    { id: 12, top: 565, left: 515 },
    { id: 13, top: 265, left: 315},
    { id: 14, top: 265, left: 415 },
    { id: 15, top: 265, left: 165 },
    { id: 16, top: 265, left: 50 },
    { id: 17, top: 465, left: 315 },
    { id: 18, top: 560, left: 315},
    { id: 19, top: 365, left: 315},
    { id: 20, top: 560, left: 100 },
    { id: 21, top: 15, left: 700 },
    { id: 22, top: 15, left: 730 },
    { id: 23, top: 15, left: 760 },
    { id: 24, top: 35, left: 745 },
    { id: 25, top: 35, left: 715 },
    { id: 26, top: 55, left: 730 },
    { id: 27, top: 265, left: 765 },
    { id: 28, top: 165, left: 690 },
  ];
  
  export default diamonds;
  