// src/components/Game.js
import React, { useState, useEffect } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import Player from './Player';
import Diamond from './Diamond';
import BaseThief from './BaseThief';
import BasePolice from './BasePolice';
import axios from 'axios';
import config from '../config/config';
import GameInfo from '../componetsStile/GameInfo';
import GameOver from '../componetsStile/GameOver';


const Game = ({ player }) => {
  const [gameState, setGameState] = useState([]); // Inicializa gameState como un array vacío
  const [players, setPlayers] = useState([player]);
  const [playerDirection, setPlayerDirection] = useState(player.direction);
  const [thiefLives, setThiefLives] = useState(3);
  const [gameOver, setGameOver] = useState(false);
  const [howWin, setHowWin] = useState("police");
  const [score, setScore] = useState(player.score);

  useEffect(() => {
    const client = new Client({
      brokerURL: `ws://localhost:8080/game-websocket`,
      connectHeaders: {
        login: 'user',
        passcode: 'password'
      },
      debug: function (str) {
        console.log(str);
      },
      reconnectDelay: 5000,
      heartbeatIncoming: 4000,
      heartbeatOutgoing: 4000,
      webSocketFactory: () => new SockJS(`${config.BASE_URL}/game-websocket`),
    });

    client.onConnect = () => {
      console.log('Connected to WebSocket');
      client.subscribe('/topic/players', message => {
        const updatedPlayers = JSON.parse(message.body);
        setPlayers(Array.isArray(updatedPlayers) ? updatedPlayers : []);
      });
    };

    client.activate();

    return () => {
      client.deactivate();
    };
  }, [player]);

  useEffect(() => {
    const fetchGameState = async () => {
      try {
        const response = await axios.post(`${config.BASE_URL}/api/games/state?gameId=1`, { players: players });
        console.log('Received game state from backend:', response.data);
        setGameState(Array.isArray(response.data) ? response.data : []);
      } catch (error) {
        console.error('Error fetching game state:', error);
      }
    };

    fetchGameState();
  }, [players]);

  const handleKeyDown = (event) => {
    if (gameState.length === 0) return; // Salir si gameState aún no está disponible
    let { top, left, isThief, initialTop, initialLeft } = player;
    let newTop = top;
    let newLeft = left;
    let newDirection = playerDirection;
    let newX = Math.floor(left / 50);
    let newY = Math.floor(top / 50);

    switch (event.key) {
      case 'ArrowUp':
        newY = newY - 1;
        newDirection = 'up';
        break;
      case 'ArrowDown':
        newY = newY + 1;
        newDirection = 'down';
        break;
      case 'ArrowLeft':
        newX = newX - 1;
        newDirection = 'left';
        break;
      case 'ArrowRight':
        newX = newX + 1;
        newDirection = 'right';
        break;
      case ' ':
        // Solo capturar ladrones si se presiona la tecla espacio y el jugador es policía
        if (!isThief && gameState[newY][newX] === 2) {
          setThiefLives(thiefLives - 1);
          setPlayers(prevPlayers => {
            if (!Array.isArray(prevPlayers)) return [];
            return prevPlayers.map(p =>
              p.isThief && Math.floor(p.left / 50) === newX && Math.floor(p.top / 50) === newY
                ? { ...p, top: p.initialTop, left: p.initialLeft }
                : p
            );
          });
          if (thiefLives <= 1) {
            setGameOver(true);
            setHowWin('police');
          }
        }
        return; // Salir de la función sin actualizar la posición
      default:
        break;
    }

    // Comprobar que la nueva posición está dentro de los límites de la matriz y no colisiona con obstáculos
    if (newX >= 0 && newX < 20 && newY >= 0 && newY < 20 && gameState[newY][newX] !== 4) {
      setPlayerDirection(newDirection);

      if (isThief) {
        // Capturar diamantes solo si el jugador es un ladrón
        if (gameState[newY][newX] === 3) {
          setScore(score + 1);
        }
      }

      // Actualizar la matriz
      setGameState(prevState => {
        if (!Array.isArray(prevState)) return [];
        const newState = prevState.map(row => row.slice());
        newState[Math.floor(top / 50)][Math.floor(left / 50)] = 0; // Limpiar la posición anterior
        newState[newY][newX] = player.isThief ? 2 : 1; // Actualizar la nueva posición
        return newState;
      });

      // Actualizar la posición del jugador
      setPlayers(prevPlayers => {
        if (!Array.isArray(prevPlayers)) return [];
        return prevPlayers.map(p =>
          p.id === player.id ? { ...p, top: newY * 50, left: newX * 50, direction: newDirection } : p
        );
      });
    }
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [player, playerDirection, gameState]);

  if (gameState.length === 0) {
    return <div>Loading game state...</div>;
  }

  if (gameOver) {
    return <GameOver score={score} howWin={howWin} />;
  }

  return (
    <>
      <GameInfo score={score} thiefLives={thiefLives} />
      <div className="game-container">
        {gameState.map((row, y) =>
          row.map((cell, x) => {
            switch (cell) {
              case 1:
                return <Player key={`player-${x}-${y}`} x={x} y={y} direction={playerDirection} paso1={true} type="police" />;
              case 2:
                return <Player key={`player-${x}-${y}`} x={x} y={y} direction={playerDirection} paso1={true} type="thief" />;
              case 3:
                return <Diamond key={`diamond-${x}-${y}`} x={x} y={y} />;
              case 4:
                return <div key={`obstacle-${x}-${y}`} className="obstacle" style={{ top: `${y * 50}px`, left: `${x * 50}px` }} />;
              case 5:
                return <BaseThief key={`baseThief-${x}-${y}`} x={x} y={y} />;
              case 6:
                return <BasePolice key={`basePolice-${x}-${y}`} x={x} y={y} />;
              default:
                return null;
            }
          })
        )}
      </div>
    </>
  );
};

export default Game;