// src/App.js
import React from 'react';
import Login from './Login';
import './App.css';

function App() {
  return (
    <div className="App">
      <Login />
    </div>
  );
}

export default App;


